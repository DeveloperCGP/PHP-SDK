var QuixParameters_8php =
[
    [ "QuixParameters", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters.html", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters" ]
];