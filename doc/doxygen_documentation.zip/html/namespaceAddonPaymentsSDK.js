var namespaceAddonPaymentsSDK =
[
    [ "Config", "namespaceAddonPaymentsSDK_1_1Config.html", "namespaceAddonPaymentsSDK_1_1Config" ],
    [ "NotificationModel", "namespaceAddonPaymentsSDK_1_1NotificationModel.html", "namespaceAddonPaymentsSDK_1_1NotificationModel" ],
    [ "QuixNotificationModel", "namespaceAddonPaymentsSDK_1_1QuixNotificationModel.html", "namespaceAddonPaymentsSDK_1_1QuixNotificationModel" ],
    [ "Requests", "namespaceAddonPaymentsSDK_1_1Requests.html", "namespaceAddonPaymentsSDK_1_1Requests" ],
    [ "Traits", "namespaceAddonPaymentsSDK_1_1Traits.html", null ],
    [ "AddonPaymentsSDK", "classAddonPaymentsSDK_1_1AddonPaymentsSDK.html", "classAddonPaymentsSDK_1_1AddonPaymentsSDK" ],
    [ "NotificationHandler", "classAddonPaymentsSDK_1_1NotificationHandler.html", "classAddonPaymentsSDK_1_1NotificationHandler" ]
];