var namespaceAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils =
[
    [ "ExtraDetails", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails" ],
    [ "MPI", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1MPI.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1MPI" ],
    [ "OptionalTransactionParams", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1OptionalTransactionParams.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1OptionalTransactionParams" ],
    [ "PaymentDetails", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1PaymentDetails.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1PaymentDetails" ],
    [ "RespCode", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1RespCode.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1RespCode" ]
];