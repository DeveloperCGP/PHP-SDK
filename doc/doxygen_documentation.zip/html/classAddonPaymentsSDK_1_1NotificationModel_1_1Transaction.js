var classAddonPaymentsSDK_1_1NotificationModel_1_1Transaction =
[
    [ "__construct", "classAddonPaymentsSDK_1_1NotificationModel_1_1Transaction.html#a5dc91ccd797701a5827e2ca23ba6ffff", null ],
    [ "getMessage", "classAddonPaymentsSDK_1_1NotificationModel_1_1Transaction.html#a0b0e611236742aac18ba1936d03ba89a", null ],
    [ "getOperations", "classAddonPaymentsSDK_1_1NotificationModel_1_1Transaction.html#a777a04327f8bbd42961bfa65ee760049", null ],
    [ "getOptionalTransactionParams", "classAddonPaymentsSDK_1_1NotificationModel_1_1Transaction.html#ad7743ca0f75ba99e1910cba608b510bf", null ],
    [ "getStatus", "classAddonPaymentsSDK_1_1NotificationModel_1_1Transaction.html#a9d21636071f529e2154051d3ea6e5921", null ],
    [ "getWorkFlowResponse", "classAddonPaymentsSDK_1_1NotificationModel_1_1Transaction.html#a87bad117191189c9ea5277d40acc9eb8", null ]
];