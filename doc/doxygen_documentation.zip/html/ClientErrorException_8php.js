var ClientErrorException_8php =
[
    [ "ClientErrorException", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ClientErrorException.html", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ClientErrorException" ]
];