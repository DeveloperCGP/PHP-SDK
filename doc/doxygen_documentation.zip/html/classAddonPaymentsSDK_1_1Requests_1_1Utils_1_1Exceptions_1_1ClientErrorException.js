var classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ClientErrorException =
[
    [ "__construct", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ClientErrorException.html#a5cf01f4095b3c763626553111452aa6e", null ],
    [ "getStatusCode", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ClientErrorException.html#a094778dd1c04fe44626000b47ea0c0bb", null ],
    [ "$statusCode", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ClientErrorException.html#ab8fd5dc19b2fe997b258a4314d404f29", null ]
];