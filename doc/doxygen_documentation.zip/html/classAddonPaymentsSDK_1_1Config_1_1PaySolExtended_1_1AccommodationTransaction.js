var classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1AccommodationTransaction =
[
    [ "addItem", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1AccommodationTransaction.html#a0552281f1cfc2a5a9f92639c0f7eb38b", null ]
];