var classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ServerErrorException =
[
    [ "__construct", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ServerErrorException.html#afba45c6823165cebc1c35a784846024c", null ],
    [ "getStatusCode", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ServerErrorException.html#a094778dd1c04fe44626000b47ea0c0bb", null ],
    [ "$statusCode", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ServerErrorException.html#ab8fd5dc19b2fe997b258a4314d404f29", null ]
];