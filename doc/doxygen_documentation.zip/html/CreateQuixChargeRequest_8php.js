var CreateQuixChargeRequest_8php =
[
    [ "CreateQuixChargeRequest", "classAddonPaymentsSDK_1_1Requests_1_1CreateQuixChargeRequest.html", "classAddonPaymentsSDK_1_1Requests_1_1CreateQuixChargeRequest" ]
];