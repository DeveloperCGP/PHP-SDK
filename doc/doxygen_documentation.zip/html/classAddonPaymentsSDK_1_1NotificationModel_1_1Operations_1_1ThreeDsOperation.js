var classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation =
[
    [ "__construct", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#ac36b2814095b231f21cb40d60f1fa74e", null ],
    [ "getAmount", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a4097b54f79b8353b00e8b6712f845562", null ],
    [ "getCurrency", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a55459f9e07fdc6b85953811024ab61d3", null ],
    [ "getMerchantTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a80a0dc5df8585f5cb1e59258959dec56", null ],
    [ "getMessage", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a0b0e611236742aac18ba1936d03ba89a", null ],
    [ "getMPI", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a458b2356276e8b3171b7347014fe5fc4", null ],
    [ "getOperationType", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a9f3d85f8ab249ce7aeb2ba0a7b7d29c2", null ],
    [ "getPayFrexTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#af05fd5f87206ae5e510eee5bf3ea3ed2", null ],
    [ "getPaymentCode", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#ac44b501cc6704859f6c1eadc0101bacc", null ],
    [ "getPaymentDetails", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a396cbf4ea2f7cd341779c734a8fc2cf5", null ],
    [ "getPaymentMessage", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#af6cd0d8c7c764597da2d4577ed071c72", null ],
    [ "getRedirectionResponse", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a0b983e82c68b0d830f03b3bd70507022", null ],
    [ "getRespCode", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a739f11d0f79abc4922cac2c1f388c169", null ],
    [ "getService", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#ae2ec6b84e042bbd7a712d834a5d46f1f", null ],
    [ "getStatus", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a9d21636071f529e2154051d3ea6e5921", null ],
    [ "getTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1ThreeDsOperation.html#a83a4c2954e4da6dad24e596265e33d0a", null ]
];