var classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Utils_1_1Billing =
[
    [ "getBilling", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Utils_1_1Billing.html#a21907527e11cc468216fdc42a32b7eb0", null ],
    [ "setBillingAddress", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Utils_1_1Billing.html#a4c254e8076fc109b2f10b24a2708aa75", null ],
    [ "setBillingCorporateIdNnumber", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Utils_1_1Billing.html#a408ecbf84518814bfd754f0da6f3d4ec", null ],
    [ "setBillingFirstName", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Utils_1_1Billing.html#a086fc72d42db8eb6dc535e97ececb6dd", null ],
    [ "setBillingLastName", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Utils_1_1Billing.html#af4434ca00948d30132984fc64f37c881", null ]
];