var ResponseQuix_8php =
[
    [ "ResponseQuix", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1ResponseQuix.html", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1ResponseQuix" ]
];