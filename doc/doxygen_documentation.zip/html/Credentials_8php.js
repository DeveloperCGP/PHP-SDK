var Credentials_8php =
[
    [ "Credentials", "classAddonPaymentsSDK_1_1Config_1_1Credentials.html", "classAddonPaymentsSDK_1_1Config_1_1Credentials" ]
];