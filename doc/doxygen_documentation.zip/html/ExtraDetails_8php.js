var ExtraDetails_8php =
[
    [ "ExtraDetails", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails" ]
];