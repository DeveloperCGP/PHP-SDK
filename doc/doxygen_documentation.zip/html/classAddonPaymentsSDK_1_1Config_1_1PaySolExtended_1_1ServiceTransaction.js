var classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1ServiceTransaction =
[
    [ "addItem", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1ServiceTransaction.html#a6eaf40920acb4bd5781c2ec4e9a8ecb1", null ]
];