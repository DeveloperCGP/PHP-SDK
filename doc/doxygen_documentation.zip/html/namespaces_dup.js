var namespaces_dup =
[
    [ "AddonPaymentsSDK", "namespaceAddonPaymentsSDK.html", "namespaceAddonPaymentsSDK" ]
];