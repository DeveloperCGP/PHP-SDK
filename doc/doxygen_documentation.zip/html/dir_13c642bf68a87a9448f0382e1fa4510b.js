var dir_13c642bf68a87a9448f0382e1fa4510b =
[
    [ "Utils", "dir_024b34c33828c08e596187780f925ffa.html", "dir_024b34c33828c08e596187780f925ffa" ],
    [ "AccommodationItem.php", "AccommodationItem_8php.html", "AccommodationItem_8php" ],
    [ "FlightItem.php", "FlightItem_8php.html", "FlightItem_8php" ],
    [ "Item.php", "Item_8php.html", "Item_8php" ],
    [ "ProductItem.php", "ProductItem_8php.html", "ProductItem_8php" ],
    [ "ServiceItem.php", "ServiceItem_8php.html", "ServiceItem_8php" ]
];