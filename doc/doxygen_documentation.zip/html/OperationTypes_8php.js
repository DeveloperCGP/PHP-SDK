var OperationTypes_8php =
[
    [ "OperationTypes", "OperationTypes_8php.html#af8946226b705130de2f1106622e95692", [
      [ "CREDIT", "OperationTypes_8php.html#af8946226b705130de2f1106622e95692a5b9c7596aea45aa4b6b3fc93a907391d", null ]
    ] ]
];