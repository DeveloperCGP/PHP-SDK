var searchData=
[
  ['environment_0',['Environment',['../namespaceAddonPaymentsSDK_1_1Config_1_1Enums.html#a2a5e3ada4b8b06f19ad6f2c239a7599a',1,'AddonPaymentsSDK::Config::Enums']]]
];
