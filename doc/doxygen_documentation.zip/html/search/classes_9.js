var searchData=
[
  ['operation_0',['Operation',['../classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Operation.html',1,'AddonPaymentsSDK::QuixNotificationModel']]],
  ['operations_1',['Operations',['../classAddonPaymentsSDK_1_1NotificationModel_1_1Operations.html',1,'AddonPaymentsSDK::NotificationModel']]],
  ['optionaltransactionparams_2',['OptionalTransactionParams',['../classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1OptionalTransactionParams.html',1,'AddonPaymentsSDK::QuixNotificationModel::Utils']]]
];
