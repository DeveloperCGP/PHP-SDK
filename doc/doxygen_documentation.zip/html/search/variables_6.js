var searchData=
[
  ['void_5fprod_0',['VOID_PROD',['../classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1RequestsPaths.html#a208b36be32e59b0565ece09dfda3b5dc',1,'AddonPaymentsSDK::Requests::Utils::RequestsPaths']]],
  ['void_5fstg_1',['VOID_STG',['../classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1RequestsPaths.html#ae9b1cda1fcc970d20d5b46e29d3d8230',1,'AddonPaymentsSDK::Requests::Utils::RequestsPaths']]]
];
