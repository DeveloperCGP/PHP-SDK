var searchData=
[
  ['handlehttpexception_0',['handleHttpException',['../classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1HttpExceptionHandler.html#ad14a3915f37d1695db89d93bcd899831',1,'AddonPaymentsSDK::Requests::Utils::HttpExceptionHandler']]],
  ['handlenotification_1',['handleNotification',['../classAddonPaymentsSDK_1_1NotificationHandler.html#a2d196c1c5915ebfb52c55d8f7f6e751d',1,'AddonPaymentsSDK::NotificationHandler']]]
];
