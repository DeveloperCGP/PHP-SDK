var searchData=
[
  ['extradetails_0',['ExtraDetails',['../classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails.html',1,'AddonPaymentsSDK::QuixNotificationModel::Utils']]],
  ['extradetailsprocessor_1',['ExtraDetailsProcessor',['../classAddonPaymentsSDK_1_1NotificationModel_1_1Utils_1_1ExtraDetailsProcessor.html',1,'AddonPaymentsSDK::NotificationModel::Utils']]]
];
