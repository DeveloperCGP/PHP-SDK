var searchData=
[
  ['workflowresponse_0',['WorkFlowResponse',['../classAddonPaymentsSDK_1_1NotificationModel_1_1WorkFlowResponse.html',1,'WorkFlowResponse'],['../classAddonPaymentsSDK_1_1QuixNotificationModel_1_1WorkFlowResponse.html',1,'WorkFlowResponse']]]
];
