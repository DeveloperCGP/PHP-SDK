var searchData=
[
  ['segment_0',['Segment',['../classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Segment.html',1,'AddonPaymentsSDK::Config::PaySolExtended::Items::Utils']]],
  ['servererrorexception_1',['ServerErrorException',['../classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ServerErrorException.html',1,'AddonPaymentsSDK::Requests::Utils::Exceptions']]],
  ['serviceitem_2',['ServiceItem',['../classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1ServiceItem.html',1,'AddonPaymentsSDK::Config::PaySolExtended::Items']]],
  ['servicetransaction_3',['ServiceTransaction',['../classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1ServiceTransaction.html',1,'AddonPaymentsSDK::Config::PaySolExtended']]]
];
