var searchData=
[
  ['quixparameters_0',['QuixParameters',['../classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters.html',1,'AddonPaymentsSDK::Config::Parameters']]],
  ['quixtransaction_1',['QuixTransaction',['../classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction.html',1,'AddonPaymentsSDK::QuixNotificationModel']]]
];
