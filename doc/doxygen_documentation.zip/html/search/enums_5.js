var searchData=
[
  ['operationtypes_0',['OperationTypes',['../namespaceAddonPaymentsSDK_1_1Config_1_1Enums.html#af8946226b705130de2f1106622e95692',1,'AddonPaymentsSDK::Config::Enums']]]
];
