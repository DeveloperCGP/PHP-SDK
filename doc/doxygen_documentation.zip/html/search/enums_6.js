var searchData=
[
  ['paymentsolutions_0',['PaymentSolutions',['../namespaceAddonPaymentsSDK_1_1Config_1_1Enums.html#aa8bf8c6b03a843793efd71bf33bdc0e7',1,'AddonPaymentsSDK::Config::Enums']]]
];
