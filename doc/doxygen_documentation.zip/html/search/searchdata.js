var indexSectionsWithContent =
{
  0: "$_abcefghijlmnopqrstvwz",
  1: "abcefhimnopqrstvw",
  2: "a",
  3: "abcefhilmnopqrstv",
  4: "_aceghiprsv",
  5: "$chjmrv",
  6: "ceilmoprt",
  7: "aceirsz",
  8: "aps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Pages"
};

