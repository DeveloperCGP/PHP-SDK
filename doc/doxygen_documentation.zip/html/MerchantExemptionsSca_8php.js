var MerchantExemptionsSca_8php =
[
    [ "MerchantExemptionsSca", "MerchantExemptionsSca_8php.html#a413dd95a6be50daad06b8e78e21c1f24", [
      [ "COR", "MerchantExemptionsSca_8php.html#a413dd95a6be50daad06b8e78e21c1f24ac871785230aa72d93e36e8e04db6b431", null ]
    ] ]
];