var namespaceAddonPaymentsSDK_1_1QuixNotificationModel =
[
    [ "Utils", "namespaceAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils.html", "namespaceAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils" ],
    [ "Operation", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Operation.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Operation" ],
    [ "QuixTransaction", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction" ],
    [ "WorkFlowResponse", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1WorkFlowResponse.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1WorkFlowResponse" ]
];