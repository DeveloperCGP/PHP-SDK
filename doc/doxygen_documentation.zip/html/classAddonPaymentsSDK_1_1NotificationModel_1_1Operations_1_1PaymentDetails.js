var classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails =
[
    [ "__construct", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails.html#ab3734a34c16bcc01bbb7409161f467eb", null ],
    [ "getCardHolderName", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails.html#acb0a8635094d15d430292328eb02561a", null ],
    [ "getCardNumber", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails.html#adb7f1b0e79041083d3e17c7f048c196a", null ],
    [ "getCardNumberToken", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails.html#af6d73bb46f4bf117beff91de41d95b98", null ],
    [ "getCardType", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails.html#a23572070315675df5c7c4e24b1a9a208", null ],
    [ "getExpDate", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails.html#a19086c833a2abb3bef0724190fc94738", null ],
    [ "getExtraDetails", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails.html#a694d79f232fce531857240bf536f9be5", null ],
    [ "getIssuerBank", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails.html#a3fbed9c8729b1afe048fab7486bb35fa", null ],
    [ "getIssuerCountry", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentDetails.html#a186bce010548ed7bacb56d9f48cd64b4", null ]
];