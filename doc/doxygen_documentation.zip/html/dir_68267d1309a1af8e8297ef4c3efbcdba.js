var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "Config", "dir_55be27304aee4fac13a1eb8fc08f58b6.html", "dir_55be27304aee4fac13a1eb8fc08f58b6" ],
    [ "NotificationModel", "dir_ce7dda9100169c45b257a84ddf316c7d.html", "dir_ce7dda9100169c45b257a84ddf316c7d" ],
    [ "QuixNotificationModel", "dir_72a36032688034f0d10077dba8f3232b.html", "dir_72a36032688034f0d10077dba8f3232b" ],
    [ "Requests", "dir_89e0e21486e321f1259043044bdeac43.html", "dir_89e0e21486e321f1259043044bdeac43" ],
    [ "Traits", "dir_dd0186e88bcf2261bcfae13d9c9e18a7.html", "dir_dd0186e88bcf2261bcfae13d9c9e18a7" ],
    [ "AddonPaymentsSDK.php", "AddonPaymentsSDK_8php.html", "AddonPaymentsSDK_8php" ],
    [ "NotificationHandler.php", "NotificationHandler_8php.html", "NotificationHandler_8php" ]
];