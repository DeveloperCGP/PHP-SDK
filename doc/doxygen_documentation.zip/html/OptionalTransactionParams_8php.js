var OptionalTransactionParams_8php =
[
    [ "OptionalTransactionParams", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1OptionalTransactionParams.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1OptionalTransactionParams" ]
];