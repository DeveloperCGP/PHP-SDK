var QuixNotificationModel_2Utils_2PaymentDetails_8php =
[
    [ "PaymentDetails", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1PaymentDetails.html", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1PaymentDetails" ]
];