var RequestsPaths_8php =
[
    [ "RequestsPaths", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1RequestsPaths.html", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1RequestsPaths" ]
];