var classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction =
[
    [ "__construct", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction.html#a1d08d87e6d60a5e2b8fda85161fb3a6c", null ],
    [ "getMessage", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction.html#a0b0e611236742aac18ba1936d03ba89a", null ],
    [ "getOperation", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction.html#aba8109788acbb11ada980b51979b331e", null ],
    [ "getOperationSize", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction.html#a3333fca7e04225a3af04666c1f0d57d8", null ],
    [ "getOptionalTransactionParams", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction.html#ad7743ca0f75ba99e1910cba608b510bf", null ],
    [ "getStatus", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction.html#a9d21636071f529e2154051d3ea6e5921", null ],
    [ "getWorkFlowResponse", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1QuixTransaction.html#a87bad117191189c9ea5277d40acc9eb8", null ]
];