var classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Passenger =
[
    [ "getPassenger", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Passenger.html#acdb659e7ddaf366bbfc143de8de85cd9", null ],
    [ "setFirstName", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Passenger.html#a4a951776a912492eb02ce00bb0b1e2ce", null ],
    [ "setLastName", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Passenger.html#a69a8e387abf5660e10ce12c2b85539ea", null ],
    [ "validate", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Passenger.html#a184909dab34698899937d810a9f5d393", null ]
];