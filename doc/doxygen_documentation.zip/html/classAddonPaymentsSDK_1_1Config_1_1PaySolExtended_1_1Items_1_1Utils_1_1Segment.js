var classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Segment =
[
    [ "getSegment", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Segment.html#ac884b610c4c19bdadf754112a83771db", null ],
    [ "setIataDepartureCode", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Segment.html#a2a9451c183409d7c88dc141a9470003b", null ],
    [ "setIataDestinationCode", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Segment.html#a022e44a3a3339443134def77e1c2a553", null ]
];