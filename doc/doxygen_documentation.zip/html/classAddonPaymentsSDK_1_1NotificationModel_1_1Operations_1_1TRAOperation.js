var classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation =
[
    [ "__construct", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#ac36b2814095b231f21cb40d60f1fa74e", null ],
    [ "getAmount", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#a4097b54f79b8353b00e8b6712f845562", null ],
    [ "getCurrency", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#a55459f9e07fdc6b85953811024ab61d3", null ],
    [ "getMerchantTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#a80a0dc5df8585f5cb1e59258959dec56", null ],
    [ "getOperationType", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#a9f3d85f8ab249ce7aeb2ba0a7b7d29c2", null ],
    [ "getPayFrexTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#af05fd5f87206ae5e510eee5bf3ea3ed2", null ],
    [ "getPaySolTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#a91437aecde90604f626bc33389b92250", null ],
    [ "getRespCode", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#a739f11d0f79abc4922cac2c1f388c169", null ],
    [ "getService", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#ae2ec6b84e042bbd7a712d834a5d46f1f", null ],
    [ "getStatus", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#a9d21636071f529e2154051d3ea6e5921", null ],
    [ "getTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1TRAOperation.html#a83a4c2954e4da6dad24e596265e33d0a", null ]
];