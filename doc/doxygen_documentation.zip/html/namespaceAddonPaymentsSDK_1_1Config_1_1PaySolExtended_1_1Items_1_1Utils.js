var namespaceAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils =
[
    [ "Passenger", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Passenger.html", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Passenger" ],
    [ "Segment", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Segment.html", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Utils_1_1Segment" ]
];