var classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails =
[
    [ "__construct", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails.html#ab20e01ed6e1235ba39397c2e30ea83ff", null ],
    [ "getNemuruAuthToken", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails.html#a12a616a38e98f3cc36952b4b4853bae4", null ],
    [ "getNemuruCartHash", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails.html#a3989bc7ef6f5c0c8b00ad9bd2be539bf", null ],
    [ "getNemuruDisableFormEdition", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails.html#a0cfea3ff437faea2c7cd5f0f3d6f3157", null ],
    [ "getNemuruTxnId", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails.html#a2867a066961c551491c14db1dca612d8", null ],
    [ "getStatus", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1ExtraDetails.html#a9d21636071f529e2154051d3ea6e5921", null ]
];