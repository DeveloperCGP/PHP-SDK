var namespaceAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions =
[
    [ "ClientErrorException", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ClientErrorException.html", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ClientErrorException" ],
    [ "FieldException", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1FieldException.html", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1FieldException" ],
    [ "InvalidFieldException", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1InvalidFieldException.html", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1InvalidFieldException" ],
    [ "MissingFieldException", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1MissingFieldException.html", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1MissingFieldException" ],
    [ "NetworkException", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1NetworkException.html", null ],
    [ "ServerErrorException", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ServerErrorException.html", "classAddonPaymentsSDK_1_1Requests_1_1Utils_1_1Exceptions_1_1ServerErrorException" ]
];