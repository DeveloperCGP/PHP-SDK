var ItemTypes_8php =
[
    [ "ItemTypes", "ItemTypes_8php.html#a826860bfcf4c0224f3daef052a18179d", [
      [ "ACCOMMODATION", "ItemTypes_8php.html#a826860bfcf4c0224f3daef052a18179dadd6d7027c2aa80896110c572dc800a2b", null ]
    ] ]
];