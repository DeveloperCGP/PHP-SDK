var classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item =
[
    [ "__construct", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a095c5d389db211932136b53f25f39685", null ],
    [ "getItem", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a094b2839a8ef421bca847866dc22ab33", null ],
    [ "getTotalPriceWithTax", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a35a4771d5f2b6d33742346d1c9a4fe37", null ],
    [ "setAutoShipping", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#af38b4ae0464e7b5c511672306a583222", null ],
    [ "setBrand", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#acba754ea4dd35fef4b3a11ce70ed796f", null ],
    [ "setCategory", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a47db7682df199825f9d8b2e51b5fcf4b", null ],
    [ "setDescription", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a3eda7afea80371b606cd289c66ab3e7c", null ],
    [ "setImageUrl", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#ace4e0bfe2db1b1223f88884b0052b1bc", null ],
    [ "setMPN", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#af158e35c2812c89a3bf05b7b60520b53", null ],
    [ "setName", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a392752b62c4f6aacea5c269690921ef3", null ],
    [ "setReference", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a65e6535d49b820f6019d2113bd617873", null ],
    [ "setTotalDiscount", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a9d767632f299f05229f372a31520bfb1", null ],
    [ "setTotalPriceWithTax", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a7450e14f0ecf30c8c1232d494d94bf8d", null ],
    [ "setType", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#afc83d98591365d3b57e48c88137e258f", null ],
    [ "setUnitPriceWithTax", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a7c25cbc6dfcbcdb1d54c2d2ed802047d", null ],
    [ "setUnits", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a57f150d65f372d50e6f3a15c610d2149", null ],
    [ "setURL", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#af9d48240946636fdab5c0c5b8afaf31f", null ],
    [ "validate", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a184909dab34698899937d810a9f5d393", null ],
    [ "$item", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1Item.html#a40624a1864f2b6e32e6bb258d9982e89", null ]
];