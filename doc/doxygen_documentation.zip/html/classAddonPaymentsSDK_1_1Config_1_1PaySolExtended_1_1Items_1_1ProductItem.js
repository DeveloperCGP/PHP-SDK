var classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1ProductItem =
[
    [ "__construct", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1ProductItem.html#a095c5d389db211932136b53f25f39685", null ],
    [ "validate", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1ProductItem.html#a184909dab34698899937d810a9f5d393", null ]
];