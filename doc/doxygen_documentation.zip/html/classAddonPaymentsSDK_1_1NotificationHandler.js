var classAddonPaymentsSDK_1_1NotificationHandler =
[
    [ "handleNotification", "classAddonPaymentsSDK_1_1NotificationHandler.html#a2d196c1c5915ebfb52c55d8f7f6e751d", null ],
    [ "setNotificationCallback", "classAddonPaymentsSDK_1_1NotificationHandler.html#aad447c64db8417b019d9882bca0973b6", null ]
];