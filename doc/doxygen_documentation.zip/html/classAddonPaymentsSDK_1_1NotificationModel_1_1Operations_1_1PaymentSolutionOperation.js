var classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation =
[
    [ "__construct", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#ac36b2814095b231f21cb40d60f1fa74e", null ],
    [ "getAmount", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a4097b54f79b8353b00e8b6712f845562", null ],
    [ "getAuthCode", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a51ba603198840f5de5e0c8836a85b5d7", null ],
    [ "getCurrency", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a55459f9e07fdc6b85953811024ab61d3", null ],
    [ "getDetails", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a67bcdf2ca053bbc348983454239ea980", null ],
    [ "getMerchantTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a80a0dc5df8585f5cb1e59258959dec56", null ],
    [ "getMessage", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a0b0e611236742aac18ba1936d03ba89a", null ],
    [ "getMPI", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a458b2356276e8b3171b7347014fe5fc4", null ],
    [ "getOperationType", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a9f3d85f8ab249ce7aeb2ba0a7b7d29c2", null ],
    [ "getOptionalTransactionParams", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#ad7743ca0f75ba99e1910cba608b510bf", null ],
    [ "getPaymentCode", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#ac44b501cc6704859f6c1eadc0101bacc", null ],
    [ "getPaymentDetails", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a396cbf4ea2f7cd341779c734a8fc2cf5", null ],
    [ "getPaymentMessage", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#af6cd0d8c7c764597da2d4577ed071c72", null ],
    [ "getPaymentMethod", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a6b3f87cc90ce837fd6a6502adc88930d", null ],
    [ "getPaymentSolution", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a94979db859c2516872171e65e3b2cbf3", null ],
    [ "getPaySolTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a91437aecde90604f626bc33389b92250", null ],
    [ "getRespCode", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a739f11d0f79abc4922cac2c1f388c169", null ],
    [ "getStatus", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a9d21636071f529e2154051d3ea6e5921", null ],
    [ "getSubscriptionPlan", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a13d0c411277cbf95c075c307a23420a4", null ],
    [ "getTransactionId", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1PaymentSolutionOperation.html#a83a4c2954e4da6dad24e596265e33d0a", null ]
];