var classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1OptionalTransactionParams =
[
    [ "__construct", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1OptionalTransactionParams.html#a912a372e97253d7c172904dbe58a844b", null ],
    [ "getChEmail", "classAddonPaymentsSDK_1_1QuixNotificationModel_1_1Utils_1_1OptionalTransactionParams.html#ad0ad411f92bcaa0f3919964e85c5ea26", null ]
];