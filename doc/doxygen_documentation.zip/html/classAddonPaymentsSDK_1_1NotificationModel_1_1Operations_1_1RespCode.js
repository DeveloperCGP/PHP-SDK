var classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1RespCode =
[
    [ "__construct", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1RespCode.html#aedfaf959eea929d334e9e1c10c8a6893", null ],
    [ "getCode", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1RespCode.html#ab5e24da53b4a0d0848b18c1e832f47ff", null ],
    [ "getMessage", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1RespCode.html#a0b0e611236742aac18ba1936d03ba89a", null ],
    [ "getUUID", "classAddonPaymentsSDK_1_1NotificationModel_1_1Operations_1_1RespCode.html#ade4d169112a63085e243c88230a581aa", null ]
];