var classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters =
[
    [ "__construct", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters.html#a095c5d389db211932136b53f25f39685", null ],
    [ "setCustomerNationalIdType", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters.html#ab97d37f80988948065dd2b4f69e02925", null ],
    [ "setIpAddress", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters.html#a7a209e0ecde89ab2dc25794d166b4fa0", null ],
    [ "setPaysolExtendedData", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters.html#a7f616dd38edb61d5e0675667f6060573", null ],
    [ "validate", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters.html#a184909dab34698899937d810a9f5d393", null ]
];