var namespaceAddonPaymentsSDK_1_1Config_1_1Parameters =
[
    [ "Parameters", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1Parameters.html", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1Parameters" ],
    [ "ParametersInterface", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1ParametersInterface.html", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1ParametersInterface" ],
    [ "QuixParameters", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters.html", "classAddonPaymentsSDK_1_1Config_1_1Parameters_1_1QuixParameters" ]
];