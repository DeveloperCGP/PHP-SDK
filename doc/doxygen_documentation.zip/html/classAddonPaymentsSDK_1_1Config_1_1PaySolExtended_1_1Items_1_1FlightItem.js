var classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1FlightItem =
[
    [ "__construct", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1FlightItem.html#a095c5d389db211932136b53f25f39685", null ],
    [ "addPassenger", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1FlightItem.html#a8c91f14703a7c1b9c423b719588be711", null ],
    [ "addSegment", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1FlightItem.html#a48a52dd555fbe695796fd15f8751384e", null ],
    [ "setDepartureDate", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1FlightItem.html#ac5ad2363fcc7b4e9886b4a724e93afd0", null ],
    [ "validate", "classAddonPaymentsSDK_1_1Config_1_1PaySolExtended_1_1Items_1_1FlightItem.html#a184909dab34698899937d810a9f5d393", null ]
];